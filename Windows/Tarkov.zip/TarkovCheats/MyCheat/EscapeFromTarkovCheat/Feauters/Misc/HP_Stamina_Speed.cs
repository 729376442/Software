﻿using System;
using EFT;
using EscapeFromTarkovCheat.Utils;
using UnityEngine;

namespace EscapeFromTarkovCheat.Feauters.Misc
{
    public class HP_Stamina_Speed : MonoBehaviour
    {
        public void Update()
        {
            if (Main.LocalPlayer != null && Settings.GodMode)
            {
                this.God();
            }
            if (Main.GameWorld != null && Settings.SpeedHack)
            {
                this.SpeedMod();
            }
        }

        private void God()
        {
            Player localPlayer = Main.LocalPlayer;
            if (Main.LocalPlayer.ActiveHealthController != null)
            {
                //InfiniteHP
                Main.LocalPlayer.ActiveHealthController.SetDamageCoeff(-1f);
                //负面BUFF
                Main.LocalPlayer.ActiveHealthController.RemoveNegativeEffects((EBodyPart)7);
                Main.LocalPlayer.ActiveHealthController.RestoreFullHealth();
                Main.LocalPlayer.ActiveHealthController.DoPermanentHealthBoost(2f);
                Main.LocalPlayer.ActiveHealthController.ChangeHydration(100f);
                Main.LocalPlayer.ActiveHealthController.ChangeEnergy(110f);
                Main.LocalPlayer.ActiveHealthController.FallSafeHeight = 1000f;

                //技能效果
                Main.LocalPlayer.Skills.AttentionEliteLuckySearch.Value = 1f;
                Main.LocalPlayer.Skills.AttentionLootSpeed.Value = 20f;
                //Main.LocalPlayer.Skills.StrengthBuffSprintSpeedInc.Value = 3f;
                Main.LocalPlayer.Skills.SurgerySpeed.Value = 2f;
                Main.LocalPlayer.Skills.DrawSpeed.Value = 1f;
            }

            //InfiniteStamina
            EFTHardSettings.Instance.LOOT_RAYCAST_DISTANCE = 6f;
            EFTHardSettings.Instance.DOOR_RAYCAST_DISTANCE = 6f;
            if (Main.LocalPlayer.Physical.Stamina.Current < 99f)
            {
                Main.LocalPlayer.Physical.Stamina.Current = Main.LocalPlayer.Physical.Stamina.TotalCapacity.Value;
            }
            if (Main.LocalPlayer.Physical.HandsStamina.Current < 99f)
            {
                Main.LocalPlayer.Physical.HandsStamina.Current = Main.LocalPlayer.Physical.HandsStamina.TotalCapacity.Value;
            }
            if (Main.LocalPlayer.Physical.Oxygen.Current < 99f)
            {
                Main.LocalPlayer.Physical.Oxygen.Current = Main.LocalPlayer.Physical.Oxygen.TotalCapacity.Value;
            }
        }
        private void SpeedMod()
        {
            if (Main.LocalPlayer == null && Main.MainCamera == null)
            {
                return;
            }
            if (Input.GetKey((KeyCode)119))
            {
                Main.LocalPlayer.Transform.position += Settings.SpeedMulti * Time.deltaTime * Main.MainCamera.transform.forward;
            }
            if (Input.GetKey(KeyCode.Space))
            {
                Main.LocalPlayer.MovementContext.IsGrounded = true;
                Main.LocalPlayer.MovementContext.FreefallTime = -0.4f;
            }
        }
    }
}