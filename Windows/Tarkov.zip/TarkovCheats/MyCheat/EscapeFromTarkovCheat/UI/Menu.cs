﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using EFT;
using EFT.Counters;
using EFT.InventoryLogic;
using EFT.UI;
using EscapeFromTarkovCheat;
using EscapeFromTarkovCheat.Utils;
using UnityEngine;
using static RootMotion.FinalIK.AimPoser;

namespace Menu.UI
{
    public class Menu : MonoBehaviour
    {
        private Rect MainWindow;
        private bool _visible = true;
        public string ItemID = "";
        private bool MiscMenuToggle;
        private bool SpawnMenuToggle;
        private bool LootMenuToggle;
        private Rect MiscWindow;
        private Rect SpawnWindow;
        private Rect LootWindow;

        public void GetItemsInBackpack(EquipmentSlot slot)
        {
            List<string> list = new List<string>();
            IEnumerable<Item> itemsInSlots = Main.LocalPlayer.Profile.Inventory.GetItemsInSlots(new EquipmentSlot[]
            {
                slot
            });
            if (itemsInSlots != null)
            {
                foreach (Item item in itemsInSlots)
                {
                    if (item.ShortName.Localized() == "6SH118")
                    {
                        continue;
                    }
                    list.Add("\"" + item.Template._id + "\",//" + item.ShortName.Localized());
                }
                Settings.idList = string.Join("\n", list);
            }
            else
            {
                Settings.idList = "";
            }
        }

        private void Start()
        {
            AllocConsoleHandler.Open();
            MainWindow = new Rect(60f, 160f, 180f, 100f);
            MiscWindow = new Rect(60f, 860f, 180f, 100f);
            SpawnWindow = new Rect(60f, 1140f, 180f, 100f);
            LootWindow = new Rect(370f, 160f, 180f, 100f);
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.Insert))
                _visible = !_visible;

            //if (Input.GetKeyDown(KeyCode.Delete))
            //Loader.Unload();
        }

        private void OnGUI()
        {
            if (!_visible)
                return;

            MainWindow = GUILayout.Window(0, MainWindow, RenderUi, $"Offline: {Settings.OfflineStreetStatus}");
            if (this.MiscMenuToggle)
            {
                this.MiscWindow = GUILayout.Window(1, this.MiscWindow, new GUI.WindowFunction(this.RenderUi), "Misc", Array.Empty<GUILayoutOption>());
            }
            if (this.SpawnMenuToggle)
            {
                this.SpawnWindow = GUILayout.Window(2, this.SpawnWindow, new GUI.WindowFunction(this.RenderUi), "Spawn", Array.Empty<GUILayoutOption>());
            }
            if (this.LootMenuToggle)
            {
                this.LootWindow = GUILayout.Window(3, this.LootWindow, new GUI.WindowFunction(this.RenderUi), "Loot", Array.Empty<GUILayoutOption>());
            }
        }

        private void RenderUi(int id)
        {
            switch (id)
            {
                case 0:

                    GUILayout.Label("");
                    Settings.DrawPlayers = GUILayout.Toggle(Settings.DrawPlayers, "Draw Players");
                    GUILayout.Label("");
                    if (GUILayout.Button("Misc", GUILayout.Width(220f), GUILayout.Height(30f)))
                    {
                        this.MiscMenuToggle = !this.MiscMenuToggle;
                    }
                    if (GUILayout.Button("Spawn", GUILayout.Width(220f), GUILayout.Height(30f)))
                    {
                        this.SpawnMenuToggle = !this.SpawnMenuToggle;
                    }
                    if (GUILayout.Button("Loot", GUILayout.Width(220f), GUILayout.Height(30f)))
                    {
                        this.LootMenuToggle = !this.LootMenuToggle;
                    }

                    GUILayout.Label("");

                    //if (GUILayout.Button("Airdrop", GUILayout.Width(220f), GUILayout.Height(30f)))
                    //    GenerateAirdrop();
                    //if (GUILayout.Button("Acid Green", GUILayout.Width(220f), GUILayout.Height(30f)))
                    //    GenerateAcidGreen();
                    //if (GUILayout.Button("Quest", Array.Empty<GUILayoutOption>()))
                    //    Settings.FinishQuest = true;
                    //if (GUILayout.Button("TraderStanding", Array.Empty<GUILayoutOption>()))
                    //    Settings.IncreaseTraderStanding = true;

                    GUILayout.Label("");

                    //if (GUILayout.Button("Spawn Vest", GUILayout.Width(220f), GUILayout.Height(70f)))
                    //{
                    //    Spawnitem(2);
                    //    Spawnitem(2);
                    //    Spawnitem(2);
                    //    Spawnitem(2);
                    //    Spawnitem(2);
                    //    Spawnitem(2);
                    //    Spawnitem(4);
                    //    Spawnitem(4);
                    //    Spawnitem(4);
                    //    Spawnitem(4);
                    //    Spawnitem(4);
                    //    Spawnitem(4);
                    //}

                    if (GUILayout.Button("Spawn Backpack", GUILayout.Width(220f), GUILayout.Height(70f)))
                    {
                        Spawnitem(1);
                        Spawnitem(1);
                        Spawnitem(1);
                        Spawnitem(1);
                        Spawnitem(1);
                        Spawnitem(1);
                    }

                    //if (GUILayout.Button("Spawn Container", GUILayout.Width(220f), GUILayout.Height(70f)))
                    //{
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //    Spawnitem(3);
                    //}

                    if (GUILayout.Button("★Spawn Ammo", GUILayout.Width(220f), GUILayout.Height(70f)))
                    {
                        AmmunitionCase();
                    }

                    if (GUILayout.Button("★Spawn Armor", GUILayout.Width(220f), GUILayout.Height(70f)))
                    {
                        SpawnArmor();
                    }

                    GUILayout.Label("");
                    ItemID = GUILayout.TextField(ItemID, new GUILayoutOption[]
                    {
                        GUILayout.Width(220f),
                        GUILayout.Height(70f)
                    });
                    break;
                case 1:
                    Settings.GodMode = GUILayout.Toggle(Settings.GodMode, "GodMode", Array.Empty<GUILayoutOption>());
                    Settings.DrawExfiltrationPoints = GUILayout.Toggle(Settings.DrawExfiltrationPoints, "Show Exits");
                    Settings.ForceThermal = GUILayout.Toggle(Settings.ForceThermal, "Thermal Vision", Array.Empty<GUILayoutOption>());
                    Settings.SpeedHack = GUILayout.Toggle(Settings.SpeedHack, "SpeedHack", Array.Empty<GUILayoutOption>());
                    GUILayout.Label($"Multiplier {(int)Settings.SpeedMulti}X");
                    Settings.SpeedMulti = GUILayout.HorizontalSlider(Settings.SpeedMulti, 5f, 50f);
                    GUILayout.Label("");
                    if (GUILayout.Button("Add EXP", GUILayout.Width(180f), GUILayout.Height(30f)))
                        XPAdder();
                    if (GUILayout.Button("Backpack Items", GUILayout.Width(180f), GUILayout.Height(30f)))
                        GetItemsInBackpack(EquipmentSlot.Backpack);
                    GUILayout.TextField(Settings.idList, new GUILayoutOption[]
                    {
                        GUILayout.Width(180f), GUILayout.Height(30f)
                    });
                    break;

                case 2:
                    if (GUILayout.Button("BEAR X10", GUILayout.Width(180f), GUILayout.Height(30f)))
                        Settings.BossButton1 = true;
                    if (GUILayout.Button("USEC X10", GUILayout.Width(180f), GUILayout.Height(30f)))
                        Settings.BossButton2 = true;
                    if (GUILayout.Button("Boss3", GUILayout.Width(180f), GUILayout.Height(30f)))
                        Settings.BossButton3 = true;
                    if (GUILayout.Button("Boss4", GUILayout.Width(180f), GUILayout.Height(30f)))
                        Settings.BossButton4 = true;
                    if (GUILayout.Button("Boss5", GUILayout.Width(180f), GUILayout.Height(30f)))
                        Settings.BossButton5 = true;
                    break;
                case 3:
                    Settings.DrawPlayers = GUILayout.Toggle(Settings.DrawPlayers, "Draw Players");
                    Settings.DrawPlayerLoots = GUILayout.Toggle(Settings.DrawPlayerLoots, "Draw Players Loot");
                    //Settings.DrawPlayerSkeleton = GUILayout.Toggle(Settings.DrawPlayerSkeleton, "Draw Skeleton");
                    //Settings.DrawPlayerName = GUILayout.Toggle(Settings.DrawPlayerName, "Draw Player Name");
                    GUILayout.Label($"Player Distance {(int)Settings.DrawPlayersDistance} m");
                    Settings.DrawPlayersDistance = GUILayout.HorizontalSlider(Settings.DrawPlayersDistance, 0f, 4000f);

                    Settings.DrawLootItems = GUILayout.Toggle(Settings.DrawLootItems, "Show Loot Items");
                    Settings.DrawDeadBodyItems = GUILayout.Toggle(Settings.DrawDeadBodyItems, "Show Deadbody Items");
                    GUILayout.Label($"Loot Item Distance {(int)Settings.DrawLootItemsDistance} m");
                    Settings.DrawLootItemsDistance = GUILayout.HorizontalSlider(Settings.DrawLootItemsDistance, 5f, 1000f);

                    Settings.DrawLootableContainers = GUILayout.Toggle(Settings.DrawLootableContainers, "Draw Containers");
                    GUILayout.Label($"Container Distance {(int)Settings.DrawLootableContainersDistance} m");
                    Settings.DrawLootableContainersDistance = GUILayout.HorizontalSlider(Settings.DrawLootableContainersDistance, 0f, 4000f);

                    GUILayout.Label("");

                    Settings.ValuableToggle = GUILayout.Toggle(Settings.ValuableToggle, "Valuable", Array.Empty<GUILayoutOption>());
                    Settings.WishListAmmoToggle = GUILayout.Toggle(Settings.WishListAmmoToggle, "WishList Ammo", Array.Empty<GUILayoutOption>());
                    Settings.WishListGearPlateToggle = GUILayout.Toggle(Settings.WishListGearPlateToggle, "WishList Gear&Plate", Array.Empty<GUILayoutOption>());
                    Settings.WishListConsumableToggle = GUILayout.Toggle(Settings.WishListConsumableToggle, "WishList Consumable", Array.Empty<GUILayoutOption>());
                    Settings.CheckPCItemAmmoToggle = GUILayout.Toggle(Settings.CheckPCItemAmmoToggle, "P&C Ammo", Array.Empty<GUILayoutOption>());
                    Settings.CheckPCItemGearPlateToggle = GUILayout.Toggle(Settings.CheckPCItemGearPlateToggle, "P&C Gear&Plate", Array.Empty<GUILayoutOption>());
                    Settings.TemporaryItemListToggle = GUILayout.Toggle(Settings.TemporaryItemListToggle, "Temporary", Array.Empty<GUILayoutOption>());

                    GUILayout.Label("");

                    Settings.LootMode = GUILayout.Toggle(Settings.LootMode, "LootMode", Array.Empty<GUILayoutOption>());
                    Settings.LootGroup1 = GUILayout.Toggle(Settings.LootGroup1, "LootGroup1", Array.Empty<GUILayoutOption>());
                    Settings.LootGroup2 = GUILayout.Toggle(Settings.LootGroup2, "LootGroup2", Array.Empty<GUILayoutOption>());
                    Settings.LootGroup3 = GUILayout.Toggle(Settings.LootGroup3, "LootGroup3", Array.Empty<GUILayoutOption>());
                    Settings.LootGroup4 = GUILayout.Toggle(Settings.LootGroup4, "LootGroup4", Array.Empty<GUILayoutOption>());
                    Settings.DogTagLV60 = GUILayout.Toggle(Settings.DogTagLV60, "DogTagLV60", Array.Empty<GUILayoutOption>());
                    GUILayout.Label($"PlayerCacheInterval {(int)Settings.PlayerCacheInterval} Sec");
                    Settings.PlayerCacheInterval = GUILayout.HorizontalSlider(Settings.PlayerCacheInterval, 3f, 25f);
                    break;
            }


            GUI.DragWindow();

        }

        public void SpawnArmor()
        {
            List<string> Temp = null; 
            XPAdder();
            try
            {
                switch (ItemID)
                {
                    case "60a283193cb70855c43a381d"://THOR IC
                        Temp = THOR_IC;
                        break;
                    case "545cdb794bdc2d3a198b456a"://6B43 6A
                        Temp = _6B43;
                        break;
                    case "5b44cf1486f77431723e3d05"://Gen4 Assault
                        Temp = GEN4_ASSAULT;
                        break;
                    case "5f60c74e3b85f6263c145586"://Rys-T
                        Temp = RYS_T;
                        break;
                    case "5ca20ee186f774799474abc2"://Vulkan-5
                        Temp = Vulkan_5;
                        break;
                    case "5c0e874186f7745dc7616606"://Maska 1Sch
                        Temp = Maska_1Sch;
                        break;
                    case "5c17a7ed2e2216152142459c"://AirFrame Tan
                        Temp = AirFrame_Tan;
                        break;
                    case "5a154d5cfcdbcb001a3b00da"://Fast MT Black
                        Temp = Fast_MT_Black;
                        break;
                }

                dynamic backpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Backpack).ContainedItem;
                if (!GameUtils.IsInventoryItemValid(backpack) || Temp == null)
                    return;
                ItemFactory itemFactory = new ItemFactory();
                CompoundItem ArmorBase = itemFactory.CreateCompoundItem(ItemID);
                ArmorBase.SpawnedInSession = true;
                System.Console.WriteLine("Slots Length:" + ArmorBase.Slots.Length);
                for (int i = 0; i < Temp.Count; i++)
                {
                    if (Temp[i] == "")
                    {
                        continue;
                    }

                    Item Compo = itemFactory.CreateItem(Temp[i]);
                    Compo.SpawnedInSession = true;
                    Compo.StackObjectsCount = Compo.StackMaxSize;
                    ArmorBase.Slots[i].ChangeContainedItemDirectly(Compo);
                    ArmorBase.Slots[i].ApplyContainedItem();
                }
                backpack.Grids[0].AddAnywhere(ArmorBase, EErrorHandlingType.Ignore);
            }
            catch (Exception ex)
            {
                System.Console.WriteLine($"Log: Exception occurred: {ex.Message}");
            }
        }

        public void AmmunitionCase(){
            XPAdder();
            try
            {
                dynamic backpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Backpack).ContainedItem;
                if (!Settings.Ammo.Contains(ItemID) || !GameUtils.IsInventoryItemValid(backpack))
                    return;
                ItemFactory itemFactory = new ItemFactory();
                CompoundItem Ammobox = itemFactory.CreateCompoundItem("5aafbde786f774389d0cbc0f");
                Ammobox.SpawnedInSession = true;
                for (int i = 0; i < 49; i++)
                {
                    Item Ammo = itemFactory.CreateItem(ItemID);
                    Ammo.SpawnedInSession = true;
                    Ammo.StackObjectsCount = Ammo.StackMaxSize;
                    Ammobox.Grids[0].AddAnywhere(Ammo, EErrorHandlingType.Ignore);
                }
                backpack.Grids[0].AddAnywhere(Ammobox, EErrorHandlingType.Ignore);
            }
            catch (Exception ex)
            {
                EFT.UI.ConsoleScreen.Log($"Log: Exception occurred: {ex.Message}");
            }
        }
        public void Spawnitem(int pos)
        {
            XPAdder();
            try
            {
                ItemFactory itemFactory = new ItemFactory();
                string itemId = ItemID;
                Item item = itemFactory.CreateItem(itemId);
                EFT.UI.ConsoleScreen.Log($"Log: Attempting to create item with ID: {itemId}");
                if (item == null)
                {
                    EFT.UI.ConsoleScreen.Log("Log: Failed to create item.");
                    return;
                }

                EFT.UI.ConsoleScreen.Log("Log: Item created successfully.");

                item.SpawnedInSession = true;
                item.StackObjectsCount = item.StackMaxSize;

                dynamic backpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Backpack).ContainedItem;
                dynamic vest = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.TacticalVest).ContainedItem;
                dynamic container = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.SecuredContainer).ContainedItem;
                dynamic pocket = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Pockets).ContainedItem;

                if (!item.QuestItem)
                {
                    if(pos == 1)
                    {
                        if (GameUtils.IsInventoryItemValid(backpack))
                        {
                            backpack.Grids[0].AddAnywhere(item, EErrorHandlingType.Ignore);
                            EFT.UI.ConsoleScreen.Log("Log: Item created successfully.");
                        }
                        else
                        {
                            Item newBackPackItem = itemFactory.CreateItem("5df8a4d786f77412672a1e3b"); // 6Sh118
                            if (newBackPackItem != null)
                            {
                                Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Backpack).Add(newBackPackItem, false, false);
                                dynamic newBackpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.Backpack).ContainedItem;
                                newBackpack.Grids[0].AddAnywhere(item, EErrorHandlingType.Ignore);
                            }
                        }
                    }

                    if(pos == 2)
                    {
                        if (GameUtils.IsInventoryItemValid(vest))
                        {
                            foreach (dynamic Grid in vest.Grids)
                            {
                                Grid.AddAnywhere(item, EErrorHandlingType.Ignore);
                            }
                            EFT.UI.ConsoleScreen.Log("Log: Item created successfully.");
                        }
                        else
                        {
                            Item newBackPackItem = itemFactory.CreateItem("5df8a42886f77412640e2e75"); // MPPV
                            if (newBackPackItem != null)
                            {
                                Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.TacticalVest).Add(newBackPackItem, false, false);
                                dynamic newBackpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.TacticalVest).ContainedItem;
                                foreach(dynamic Grid in newBackpack.Grids)
                                {
                                    Grid.AddAnywhere(item, EErrorHandlingType.Ignore);
                                }
                            }
                        }
                    }

                    if(pos == 3)
                    {
                        if (GameUtils.IsInventoryItemValid(container))
                        {
                            container.Grids[0].AddAnywhere(item, EErrorHandlingType.Ignore);
                            EFT.UI.ConsoleScreen.Log("Log: Item created successfully.");
                        }
                        else
                        {
                            Item newBackPackItem = itemFactory.CreateItem("5c093ca986f7740a1867ab12"); // Kappa
                            if (newBackPackItem != null)
                            {
                                Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.SecuredContainer).Add(newBackPackItem, false, false);
                                dynamic newBackpack = Main.LocalPlayer.Profile.Inventory.Equipment.GetSlot(EquipmentSlot.SecuredContainer).ContainedItem;
                                newBackpack.Grids[0].AddAnywhere(item, EErrorHandlingType.Ignore);
                            }
                        }
                    }

                    if (pos == 4)
                    {
                        if (GameUtils.IsInventoryItemValid(pocket))
                        {
                            foreach (dynamic Grid in pocket.Grids)
                            {
                                Grid.AddAnywhere(item, EErrorHandlingType.Ignore);
                            }
                        }
                    }

                }
                else
                {
                    EFT.UI.ConsoleScreen.Log("Item Is a Quest Item, doing Nothing !");
                }
            }
            catch (Exception ex)
            {
                EFT.UI.ConsoleScreen.Log($"Log: Exception occurred: {ex.Message}");
            }
        }
        public void XPAdder()
        {
            if (Main.GameWorld = null)
                return;
            Main.LocalPlayer.Profile.EftStats.SessionCounters.SetLong(500, CounterTag.Exp);
        }
        private void GenerateAirdrop()
        {
            if (Main.GameWorld != null)
            {
                Main.LocalPlayer.HandleFlareSuccessEvent(Main.LocalPlayer.Transform.position, EFT.PrefabSettings.FlareEventType.Airdrop);
            }
        }
        private void GenerateAcidGreen()
        {
            if (Main.GameWorld != null)
            {
                Main.LocalPlayer.HandleFlareSuccessEvent(Main.LocalPlayer.Transform.position, EFT.PrefabSettings.FlareEventType.AIFollowEvent); ;
            }
        }

        internal static List<string> THOR_IC = new List<string> {            "656fa61e94b480b8a500c0e8",//NESCO 4400            "656fa61e94b480b8a500c0e8",//NESCO 4400            "64afd81707e2cf40e903a316",//Granit侧板            "64afd81707e2cf40e903a316",//Granit侧板            "6575d561b15fef3dd4051670",//            "6575d56b16c2762fba005818",//            "6575d57a16c2762fba00581c",//            "6575d589b15fef3dd4051674",//            "6575d598b15fef3dd4051678",//            "6575d5b316c2762fba005824",//            "6575d5bd16c2762fba005828",//            "6575d5a616c2762fba005820",//
        };

        internal static List<string> _6B43 = new List<string> {            "656fa61e94b480b8a500c0e8",//NESCO 4400            "656fa61e94b480b8a500c0e8",//NESCO 4400            "64afd81707e2cf40e903a316",//Granit侧板            "64afd81707e2cf40e903a316",//Granit侧板            "6575ce3716c2762fba0057fd",//            "6575ce45dc9932aed601c616",//            "6575ce5016c2762fba005802",//            "6575ce5befc786cd9101a671",//            "6575ce6f16c2762fba005806",//            "6575ce9db15fef3dd4051628",//            "6575cea8b15fef3dd405162c",//            "6575ce8bdc9932aed601c61e",//
        };

        internal static List<string> GEN4_ASSAULT = new List<string> {            "656faf0ca0dce000a2020f77",//GAC 4sss2            "656faf0ca0dce000a2020f77",//GAC 4sss2            "64afdb577bb3bfe8fe03fd1d",//ESBI四级侧板            "64afdb577bb3bfe8fe03fd1d",//ESBI四级侧板            "6575c3b3dc9932aed601c5f4",//            "6575c3beefc786cd9101a5ed",//            "6575c3cdc6700bd6b40e8a90",//            "6575c3dfdc9932aed601c5f8",//            "6575c3ec52b7f8c76a05ee39",//            "6575c3fd52b7f8c76a05ee3d",//            "6575c40c52b7f8c76a05ee41",//
        };

        internal static List<string> RYS_T = new List<string> {
            "5f60c85b58eff926626a60f7",//面罩            "657bc285aab96fccee08bea3",//            "657bc2c5a1c61ee0c3036333",//            "657bc2e7b30eca976305118d",//
        };

        internal static List<string> Vulkan_5 = new List<string>
        {            "5ca2113f86f7740b2547e1d2",//面罩            "657bbe73a1c61ee0c303632b",//            "657bbed0aab96fccee08be96",//            "657bbefeb30eca9763051189",//
        };

        internal static List<string> Maska_1Sch = new List<string>
        {
            "5c0e842486f77443a74d2976",//1Sch面罩            "6571133d22996eaf11088200",//            "6571138e818110db4600aa71",//            "657112fa818110db4600aa6b",//
        };

        internal static List<string> AirFrame_Tan = new List<string>
        {            "5a16b7e1fcdbcb00165aa6c9",//面罩            "",//            "",//            "5c178a942e22164bef5ceca3",//Chops            "657f9897f4c82973640b235e",//            "657f98fbada5fadd1f07a585",//
        };

        internal static List<string> Fast_MT_Black = new List<string>
        {            "",//            "5ea058e01dbce517f324b3e2",//Heavy Trooper            "",//            "",//            "",//            "657f8ec5f4c82973640b234c",//            "657f8f10f4c82973640b2350",//
        };
    }
}
