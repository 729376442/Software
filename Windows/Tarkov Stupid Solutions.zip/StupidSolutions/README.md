# EscapeFromTarkov-Cheat
The missing references is located in your games Managed folder.
This is a pretty source, so i'll no longer work on it. Insted I might create a new project. 
Copy bundle and menu files to \AppData\LocalLow\Battlestate Games\EscapeFromTarkov
