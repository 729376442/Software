This folder contains a trimmed copy of https://github.com/rthalley/dnspython (commit eb6c2b9ab3d43542).
