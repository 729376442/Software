Cracking GNOME Keyring files
============================

1. Run keyring2john on .keyring file(s).

E.g. $ ../run/keyring2john Default.keyring > hash

2. Run john on the output of keyring2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.
