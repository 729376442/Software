Cracking Mozilla Firefox, Thunderbird and SeaMonkey master passwords
====================================================================

1. Run mozilla2john.py on key3.db file.
     ./mozilla2john /some/path/key3.db > mozilla.in

2. Run john on output of mozilla2john.
     ./john mozilla.in

3. Wait for master password to get cracked.
