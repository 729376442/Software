Cracking PST files with JtR
---------------------------

1. Run pst2john on the .pst file(s).

E.g. $ ../run/pst2john test.pst > hashes

2. Run john on the output of pst2john program.

E.g. $ ../run/john hashes

The "pst2john" program currently lives outside the JtR repository, and is
available at the https://github.com/kholia/pst2john URL.
