Cracking Apple's Mac OS Keychain files
======================================

1. Run keychain2john on .keychain file(s).

E.g. $ ../run/keychain2john login.keychain > hash

2. Run john on the output of keychain2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.
