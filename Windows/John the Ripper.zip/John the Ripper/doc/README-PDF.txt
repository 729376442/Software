Cracking PDF files with JtR
---------------------------

1. Run pdf2john.pl on the .pdf file(s).

E.g. $ ../run/pdf2john.pl test.pdf > hashes

2. Run john on the output of pdf2john.pl program.

E.g. $ ../run/john hashes
