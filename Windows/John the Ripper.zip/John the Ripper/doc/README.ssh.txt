Cracking password protected ssh private keys
============================================

1. Build JtR-jumbo

2. Run ssh2john.py on SSH private key file(s)

3. Run john on the output of step 2.
